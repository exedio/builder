/*
 * Copyright (C) 2004-2015  exedio GmbH (www.exedio.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.exedio.cope;

import gnu.trove.TLongHashSet;

abstract class ClusterUdpListenerModel extends ClusterUdpListener
{
	private final ClusterUdpSender sender;
	private final ClusterServiceParameters parameters;

	ClusterUdpListenerModel(
			final ClusterUdpProperties properties,
			final ModelMetrics metrics,
			final ClusterUdpSender sender,
			final ClusterServiceParameters parameters)
	{
		super(properties, metrics, parameters.concreteTypeCount);
		this.sender = sender;
		this.parameters = parameters;
	}

	@Override
	final void invalidate(final TLongHashSet[] invalidations, final int remoteNode)
	{
		parameters.invalidate(invalidations, remoteNode);
	}

	@Override
	final void pong(final long pingNanos, final int pingNode)
	{
		sender.pong(pingNanos, pingNode);
	}
}
