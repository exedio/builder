/*
 * Copyright (C) 2004-2012  exedio GmbH (www.exedio.com)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package com.exedio.cope;

import com.exedio.dsmf.Schema;
import com.exedio.dsmf.Sequence;
import java.sql.Connection;

final class SequenceImplSequence implements SequenceImpl
{
	private final int start;
	private final Executor executor;
	private final ConnectionPool connectionPool;
	private final String name;
	private final String quotedName;

	SequenceImplSequence(
			final IntegerColumn column,
			final int start,
			final ConnectionPool connectionPool,
			final Database database,
			final String nameSuffix)
	{
		this.start = start;
		this.executor = database.executor;
		this.connectionPool = connectionPool;
		this.name = database.properties.filterTableName(column.makeGlobalID("Seq"+nameSuffix));
		this.quotedName = database.dsmfDialect.quoteName(this.name);
	}

	SequenceImplSequence(
			final String name,
			final int start,
			final ConnectProperties properties,
			final ConnectionPool connectionPool,
			final Executor executor,
			final com.exedio.dsmf.Dialect dsmfDialect)
	{
		this.start = start;
		this.executor = executor;
		this.connectionPool = connectionPool;
		this.name = properties.filterTableName(name);
		this.quotedName = dsmfDialect.quoteName(this.name);
	}

	public void makeSchema(final Schema schema)
	{
		new Sequence(schema, name, start);
	}

	public int next()
	{
		final Connection connection = connectionPool.get(true);
		try
		{
			return executor.dialect.nextSequence(executor, connection, quotedName).intValue();
		}
		finally
		{
			connectionPool.put(connection);
		}
	}

	public int getNext()
	{
		final Connection connection = connectionPool.get(true);
		try
		{
			return executor.dialect.getNextSequence(executor, connection, name);
		}
		finally
		{
			connectionPool.put(connection);
		}
	}

	public void delete(final StringBuilder bf, final Dialect dialect)
	{
		dialect.deleteSequence(bf, quotedName, start);
	}

	public void flush()
	{
		// empty
	}

	public String getSchemaName()
	{
		return name;
	}
}
